package in.co.insurance.mgt.ctl;

import java.io.IOException;
import javax.mail.*;
import javax.mail.internet.*;
