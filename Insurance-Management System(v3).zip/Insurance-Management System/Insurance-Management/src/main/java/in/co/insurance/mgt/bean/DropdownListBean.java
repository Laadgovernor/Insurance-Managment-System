package in.co.insurance.mgt.bean;

public interface DropdownListBean {
	
	public String getKey();

	public String getValue();
}
